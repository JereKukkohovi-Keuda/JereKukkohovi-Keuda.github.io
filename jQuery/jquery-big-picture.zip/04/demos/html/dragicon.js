$(document).ready(function(){
	$("#johnDoe").draggable({ axis: "x" });
});