$(document).ready(function(){
	$("#datePicker").datepicker();
});