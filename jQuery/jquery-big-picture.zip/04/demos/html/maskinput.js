$(document).ready(function(){
	$("#datePicker").inputmask({ alias: "datetime"});
});