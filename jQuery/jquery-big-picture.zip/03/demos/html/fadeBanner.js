$(document).ready(function(){
	$("[alt='John Doe']").fadeTo(300, 0).fadeTo(300, 100);
});