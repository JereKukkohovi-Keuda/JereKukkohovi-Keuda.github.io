$(document).ready(function(){
	$("li.answer").hide();
	
	$("li.question").on("click", function(){
		$(this).next().toggle();
	});
	
	$("li.answer").hover(function(){
		// mouseenter
		$(this).addClass("hoverover");
	},
	function(){
		// mouse exit
		$(this).removeClass("hoverover");
	});
});
