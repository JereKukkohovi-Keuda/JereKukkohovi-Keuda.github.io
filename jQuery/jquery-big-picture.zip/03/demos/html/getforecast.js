$(document).ready(function(){
$.ajax({
  type: 'GET',
  url: 'https://localhost:44335/weatherforecast',
  success: function(data){
	  var forecastHTML;
	  
	  forecastHTML = buildForecastHTML(data);
	  
	  $("#forecast").html(forecastHTML);
  }
});
})

function buildForecastHTML(data){
	// return "TEST DATA";
	
	var forecastHTML = "";
	
	data.forEach((item) => {
		forecastHTML += "<div class='forecastData'><div class='forecastDate'>" + item.date + "</div>";
		forecastHTML += "<div class='temperature'>" + item.temperatureC + " degrees C</div>";
		forecastHTML += "<div class='temperature'>" + item.temperatureF + " degrees F</div>";
		forecastHTML += "<div class='forecastSummary'>" + item.summary + "</div></div>";
	});
	
	return forecastHTML;
}