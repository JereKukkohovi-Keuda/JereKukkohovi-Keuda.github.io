$(document).ready(
	function(){
		//$("h1").attr("style", "color:red");
	}
);