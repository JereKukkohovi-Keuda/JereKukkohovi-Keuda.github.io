$(document).ready(function(){
	$(".crf-cigar-banner--container").fadeTo(300, 0);
	$(".crf-cigar-banner--container").fadeTo(300, 100);
});