if (IsIE()){
	// do stuff the Microsoft way
}
else{
	// do things like everybody but Microsoft did them
}
